import express from "express";
import { request } from "http";
import WS from "ws";
import SocketServer from "./SocketServer";

const app = express();

console.log("server started");
const server = app.listen(7000);

const socketServer = new SocketServer();
socketServer
  .on("", (connection, request) => {
    console.log("BLANK HIT!");
    connection.send(200, "Hit the blank end point");
  })
  .on("/", (connection, request) => {
    console.log("/ HIT!");
    connection.send(200, "Hit the / endpoint");
  })
  .catch((connection, request) => {
    console.log("MISSED");
    console.log(request);
    connection.send(404, "Url not found");
  })
  .initSocket(server);
